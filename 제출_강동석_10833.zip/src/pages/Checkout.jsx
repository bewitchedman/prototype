export default function Checkout() {
  return <div>페이지를 찾을 수 없습니다.</div>;
}
