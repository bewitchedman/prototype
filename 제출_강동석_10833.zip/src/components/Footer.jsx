export default function Footer() {
  return (
    <footer>
      <p>© 2021 Mark Lee. All rights reserved.</p>
    </footer>
  );
}
